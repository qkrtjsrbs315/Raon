const app = express()
const router = express.router()
const Daily = require('../models/daily')

router.get('/', (req, res) => {
    res.render("daily.html")
})

router.post('/plus', (res, req) => {//temp variable
    const title = req.body.title
    const contents = req.body.id
    let daily = new Daily()
    daily.title = title
    daily.contents = contents
    Daily.save(function(err){
        if(err){
            console.error(err)
            res.send("<script>alert('로그인이 필요합니다.')</script>")
        }
    })

    
})  
router.post('/delete', (res,req) =>{
    Daily.delete()
})  