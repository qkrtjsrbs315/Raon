const express = require('express')
const router = express.Router()


router.get('/', (req, res) => {
    req.session.destroy(function(err) {
        if(err) {
            console.error(err)
        } else {
            res.send("<script>alert('로그아웃하였습니다!');location.href='/';</script>")
        }
    })
})

module.exports = router