const express = require('express')
const router = express.Router()
const User = require('../models/user')

router.get('/', (req, res) => {
    res.render("register.html")
})

router.post('/', (req, res) => {
    const name = req.body.name
    const id = req.body.id
    const password = req.body.password
    const rePassword = req.body.rePassword
    

    User.find({id:id}, function(err, user_result) {
        if(err) {
            console.error(err)
        } else {
            if(user_result.length == 0) {
                if (password === rePassword) {
                    let user = new User()
                    user.name = name
                    user.id = id
                    user.password = password
                    user.registered_date = new Date()
            
                    user.save(function(err) {
                        if(err) {
                            console.error(err)
                            res.send("<script>alert('회원가입에 실패했습니다! ㅠㅠ'</script>")
                        }
                        res.send("회원가입 성공!")
                    })
                } else {
                    res.send("<script>alert('비밀번호가 일치하지 않습니다.');history.go(-1);</script>")
                } 
            } else {
                res.send("<script>alert('이미 존재하는 계정이 있습니다!');history.go(-1);</script>")
            }
        }
    })
})

module.exports = router