const express = require('express')
const router = express.Router()
const User = require('../models/user')

router.get('/', (req, res) => {
    if(!req.session.is_logined) {
        res.render("login.html")
    } else {
        res.send("<script>alert('이미 로그인했습니다');history.go(-1);</script>")
    }
    
})

router.post('/', (req, res) => {
    const id = req.body.id
    const password = req.body.password
    User.find({id:id, password:password}, function(err, user_result) {
        if(err) {
            console.error(err)
            res.send("<script>alert('로그인에 실패했습니다');history.go(-1);</script>")
        } else {
            if(user_result.length == 0) {
                res.send("<script>alert('존재하는 계정이 없습니다!');history.go(-1);</script>")
            } else {
                req.session.user = id
                req.session.is_logined = true
                res.send(`로그인 성공! 계정은 ${id}입니다`)
            }
        }
    })
})

module.exports = router