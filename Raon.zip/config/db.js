const mongoose = require("mongoose");
// URI
const uri = "mongodb+srv://root:1234@raon.g3l09.mongodb.net/Cluster0?retryWrites=true&w=majority"
//?뭔가 인식이 안됨

// Connect MongoDB
const connectDB = async () => {
    try {
        await mongoose.connect(uri, {
            useUnifiedTopology: true,
            useNewUrlParser: true,
        });

        console.log("MongoDB Connected...");
    } catch (error) {
        console.error(error.message);
        process.exit(1);
    }
};

module.exports = connectDB;