const dailySchema = new Schema({
    title: {
        type: String,
        required: true,
    },
    contents: {
        type: String,
    }

},
    {
        timestamps: true
    })

module.exports = mongoose.model('daily', dailySchema)