const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const session = require('express-session')

const port = 3000
const connectDB = require("./config/db")
connectDB();

const registerRouter = require('./routes/register')
const loginRouter = require('./routes/login')
const logoutRouter = require('./routes/logout')

app.use(express.json())
app.use(express.urlencoded({ extended: false }))

app.use( //session구현
    session({
        key: "asd",
        secret: "raon",
        resave: false,
        saveUninitialized: false
    })
)

app.use(express.static("public"))
app.engine('html', require('ejs').renderFile)
app.set('view engine', 'html')
app.set('views', 'views')

app.use('/register', registerRouter)
app.use('/login', loginRouter)
app.use('/logout', logoutRouter)

app.get('/', (req, res) => {
    res.render("index.html")
})

app.listen(port, () => {
    console.log(`Sever is running in ${port}`)
})